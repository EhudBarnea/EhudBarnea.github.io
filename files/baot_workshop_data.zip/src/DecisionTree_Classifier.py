import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
import matplotlib.pyplot as plt
import seaborn as sns
from mlxtend.plotting import plot_decision_regions
from sklearn import tree


def split_dataset(features, labels):
    try:
        X_train, X_test, y_train, y_test = train_test_split(
            features, labels, test_size=0.1, random_state=42
        )
        return X_train, X_test, y_train, y_test
    except Exception as e:
        print("Error splitting dataset:", str(e))
        return None, None, None, None


def plot_histograms(class1_data, class2_data):
    """
    Plots histograms for two classes of data.
    """
    plt.figure()
    plt.hist(
        class1_data, bins=10, facecolor='blue', edgecolor='none',
        alpha=0.7, density=True, label='Finger'
    )
    plt.hist(
        class2_data, bins=20, facecolor='red', edgecolor='none',
        alpha=0.7, density=True, label='Palm'
    )
    plt.xlabel('Feature')
    plt.ylabel('Probability')
    plt.legend()
    plt.show()


def visualize_confusion_matrix(cm):
    """
    Visualizes the confusion matrix using a heatmap.
    """
    labels = ['finger', 'palm']
    plt.figure(figsize=(8, 6))
    sns.heatmap(
        cm, annot=True, cmap='Blues', fmt='.2f', cbar=False,
        annot_kws={"ha": 'center', "va": 'center'}
    )
    plt.title('Confusion Matrix')
    plt.xlabel('Predicted Label')
    plt.ylabel('True Label')
    plt.xticks(ticks=range(len(labels)), labels=labels)
    plt.yticks(ticks=range(len(labels)), labels=labels)
    plt.show()


def evaluate_classifier(y_true, y_pred):
    """
    Evaluates the performance of a classifier by calculating
    various evaluation metrics and displaying the results.
    """
    accuracy = accuracy_score(y_true, y_pred)
    classification_rep = classification_report(y_true, y_pred)
    confusion_mat = confusion_matrix(y_true, y_pred, normalize='true')

    print("Accuracy:", accuracy)
    print("Classification Report:\n", classification_rep)
    print("Confusion Matrix:\n", confusion_mat)

    visualize_confusion_matrix(confusion_mat)


def plot_decision_regions_func(X, y, clf):
    """
    Wraps the plot_decision_regions function to visualize
    the decision regions of a classifier.
    """
    fig, ax = plt.subplots(figsize=(7, 7))
    plot_decision_regions(X, y, clf=clf, ax=ax)
    plt.xlabel('Feature1')
    plt.ylabel('Feature2')
    plt.xlim(0, max(X[:, 0]))
    plt.ylim(0, max(X[:, 1]))

    # Create custom legend handles and labels
    handles = [plt.Line2D([], [], marker='o', color='blue', label='Finger'),
               plt.Line2D([], [], marker='o', color='orange', label='Palm')]

    # Add the custom legend
    plt.legend(handles=handles, loc='upper left')

    plt.tight_layout()
    plt.show()


def plot_tree_func(clf):
    """
    Wraps the tree.plot_tree function to visualize the decision tree.
    """
    fig, ax = plt.subplots(figsize=(12, 8))
    # tree.plot_tree(clf, filled=True, feature_names=['Size', 'Halo'], class_names=['Finger', 'Palm'],
    #                fontsize=10, label="all", impurity=False,
    #                proportion=True, rounded=True)
    tree.plot_tree(clf, filled=True, feature_names=['Feature 1', 'Feature 2'], class_names=['Class 1', 'Class 2'],
                   fontsize=10, label="all", impurity=False,
                   proportion=True, rounded=True)
    plt.show()


def main():
    # Load the dataset
    df_features = pd.read_excel('Features1.xlsx', sheet_name='Sheet1')
    df_labels = pd.read_excel('labels1.xlsx', sheet_name='Sheet1')

    features = df_features.to_numpy()
    labels = df_labels.to_numpy().flatten()

    X = features[:, [0, 3]]  # Select features
    features_names = ['Size', 'Elongation', 'Compactness', 'Halo']
    y = labels

    # Plot histograms
    class1_data = X[y == 1]  # Finger
    class2_data = X[y == 2]  # Palm

    # Challenge - Add more classes
    plot_histograms(class1_data, class2_data)

    # Split the dataset into training and testing sets
    X_train, X_test, y_train, y_test = split_dataset(X, y)

    # Train the decision tree classifier
    clf_tree = DecisionTreeClassifier(criterion='gini', max_depth=2, random_state=1)
    clf_tree.fit(X_train, y_train)

    # Make predictions on the test set and evaluate the classifier
    y_pred = clf_tree.predict(X_test)
    evaluate_classifier(y_test, y_pred)

    # Visualize decision regions and the decision tree
    X_combined = np.vstack((X_train, X_test))
    y_combined = np.hstack((y_train, y_test))

    plot_decision_regions_func(X_combined, y_combined, clf_tree)
    plot_tree_func(clf_tree)


if __name__ == '__main__':
    main()
