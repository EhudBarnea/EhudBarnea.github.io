import numpy as np
import pandas as pd
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.io as sio
from scipy.linalg import pinv



# Step 1: Load and preprocess touch dataset
def load_touch_dataset():
        # Load the touch data from Excel files
    try:
        df_features = pd.read_excel('Features1.xlsx', sheet_name='Sheet1')  # Assuming the features are in 'book1.xlsx'
        df_labels = pd.read_excel('labels1.xlsx', sheet_name='Sheet1')  # Assuming the labels are in 'book2.xlsx'

        # Convert the dataframes to numpy arrays
        features = df_features.to_numpy()
        labels = df_labels.to_numpy().flatten()
        labels = labels

        return features, labels
    except Exception as e:
        print("Error loading touch dataset:", str(e))
        return None, None


def preprocess_touch_features(features):
    # Implement any necessary preprocessing steps for your touch features
    # Return the preprocessed features
    pass

# Step 2: Split the dataset into training and testing sets
def split_dataset(features, labels):
    try:
        X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.1, random_state=42)
        return X_train, X_test, y_train, y_test
    except Exception as e:
        print("Error splitting dataset:", str(e))
        return None, None, None, None

# Step 3: Train the QDA model
def train_qda(X_train, y_train):
    qda = QuadraticDiscriminantAnalysis(priors=0.25 * np.ones(4), store_covariance=True)
    qda.fit(X_train, y_train)
    return qda

# Step 4: Predict class labels for test set
def predict(qda_model, X_test):
    y_pred_sclearn = qda_model.predict(X_test)

    K = qda_model.classes_.shape[0]
    Dim = qda_model.means_.shape[1]
    Nt = X_test.shape[0]
    D = np.zeros((Nt, K))

    for k in range(K):
        C = qda_model.covariance_[k]
        Xdiff = X_test - np.outer(np.ones(Nt), qda_model.means_[k])
        C1 = -0.5 * np.diag(np.dot(np.dot(Xdiff, pinv(C)), Xdiff.T))
        C2 = (-0.5 * np.log(np.linalg.det(C)) + np.log(0.25)) * np.ones(Nt) - 0.5 * Dim * np.log(2 * np.pi)
        D[:, k] = C1 + C2

    y_pred_ind = np.argmax(D, axis=1)
    y_pred = qda_model.classes_[y_pred_ind]

    return y_pred, y_pred_sclearn

# Step 5: Evaluate the model
def evaluate(y_test, y_pred, y_pred_sclearn):

    accuracy = accuracy_score(y_test, y_pred)
    accuracy_sclearn = accuracy_score(y_test, y_pred_sclearn)
    report = classification_report(y_test, y_pred)
    # cm = confusion_matrix(y_test, y_pred)
    normalized_cm = confusion_matrix(y_test, y_pred, normalize='true')
    normalized_cm_sclearn = confusion_matrix(y_test, y_pred_sclearn, normalize='true')

    print("Accuracy:", accuracy)
    print("Accuracy_sclearn:", accuracy_sclearn)
    print("Classification Report:")
    print(report)
    print("Confusion Matrix:")
    print(normalized_cm)
    # visualize_confusion_matrix(cm)
    visualize_confusion_matrix(normalized_cm)
    visualize_confusion_matrix(normalized_cm_sclearn)



# Step 6: Visualize the covariance matrix
def visualize_covariance_matrix(qda_model):
    cov_matrices = qda_model.covariance_
    num_classes = len(cov_matrices)

    plt.figure(figsize=(10, 8))
    for i in range(num_classes):
        plt.subplot(1, num_classes, i+1)
        plt.imshow(cov_matrices[i], cmap='hot', interpolation='nearest')
        plt.title('Covariance Matrix - Class {}'.format(i+1))
        plt.colorbar()
    plt.tight_layout()
    plt.show()

# Step 7: Visualize the confusion matrix
def visualize_confusion_matrix(cm):
    labels = ['finger', 'palm', 'smear', 'bunch']
    plt.figure(figsize=(8, 6))
    # sns.heatmap(cm, annot=True, cmap='Blues')
    sns.heatmap(cm, annot=True, cmap='Blues', fmt='.2f', cbar=False,
                annot_kws={"ha": 'center', "va": 'center'})
    plt.title('Confusion Matrix')
    plt.xlabel('Predicted Label')
    plt.ylabel('True Label')
    plt.xticks(ticks=range(len(labels)), labels=labels)
    plt.yticks(ticks=range(len(labels)), labels=labels)
    plt.show()

# Step 8: Main function
def main():
    # Step 1: Load and preprocess touch dataset
    features, labels = load_touch_dataset()
    # features = preprocess_touch_features(features)

    # Step 2: Split the dataset
    X_train, X_test, y_train, y_test = split_dataset(features, labels)

    # Step 3: Train the QDA model
    qda_model = train_qda(X_train, y_train)

    # Step 4: Predict class labels for test set
    y_pred, y_pred_sclearn = predict(qda_model, X_test)

    # Step 5: Evaluate the model
    evaluate(y_test, y_pred, y_pred_sclearn)

    # Step 6: Visualize the covariance matrix
    visualize_covariance_matrix(qda_model)

    # Create a dictionary to store the variables
    data = {'X_test': X_test, 'y_test': y_test, 'y_pred': y_pred}

    # Save the variables to a MATLAB .mat file
    sio.savemat('variables.mat', data)


# Run the main function
if __name__ == '__main__':
    main()
